import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
    String getInfo(){
        String jdbcUrl = "jdbc:oracle:thin:@(description=(address=(host=172.18.0.1)(protocol=tcp)(port=1521))(connect_data=(service_name=orclpdb1)(SERVER=DEDICATED)))";
        String username = "escolar";
        String password = "admin";
        String resp="";
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            return "Oracle JDBC driver not found";
        }

        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            if (connection != null) {
                connection.close(); // Remember to close the connection when done
                return "Connected to the database!";
            }
        } catch (SQLException e) {

            resp="Connection failed!";
        }
        return resp;
    }
}