import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class Conexion {
    Connection conn;
    public Conexion() {
        try {
            Class.forName("org.postgresql.Driver");
            String jdbcUrl = "jdbc:postgresql://172.26.172.24:5432/school?user=postgres&password=admin";
            this.conn = DriverManager.getConnection(jdbcUrl);
        } catch (Exception ex) {
            ex.printStackTrace();
            this.conn = null;
        }
    }
    public void closeConnection() {
        try {
            if (this.conn != null) {
                this.conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void listStudent() {
        try {
            PreparedStatement statement = this.conn.prepareStatement(
                    "SELECT * FROM student"
            );
            ResultSet results = statement.executeQuery();
            while (results.next()) {
                System.out.println(results.getInt("nocontrol") + "\t" + results.getString("fullname"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}